<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spring_outdoorsTileSheet" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="spring_outdoorsTileSheet.png" width="400" height="1264"/>
 <tile id="0">
  <properties>
   <property name="1" value="111"/>
  </properties>
 </tile>
</tileset>
