<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spring_outdoorsTileSheet" tilewidth="32" tileheight="32" tilecount="468" columns="12">
 <image source="../spring_outdoorsTileSheet.png" width="400" height="1264"/>
</tileset>
