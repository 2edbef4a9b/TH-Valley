<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Paths" tilewidth="16" tileheight="16" tilecount="64" columns="4">
 <image source="../paths.png" width="64" height="256"/>
</tileset>
